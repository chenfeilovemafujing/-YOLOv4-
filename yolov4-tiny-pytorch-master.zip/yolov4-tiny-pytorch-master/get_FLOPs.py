import torch
from thop import profile
import torch
from torch.autograd import Variable
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import torch.backends.cudnn as cudnn
from torch.utils.data import DataLoader
from utils.dataloader import yolo_dataset_collate, YoloDataset
from nets.yolo_training import YOLOLoss,Generator
from nets.yolo4_tiny import YoloBody



model = YoloBody(6,9)
#net = Model()  # 定义好的网络模型
input = torch.randn(1, 3, 416, 416)
flops, params = profile(model, inputs=(input, ))
print('flops: ', flops, 'params: ', params)